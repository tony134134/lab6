

export const config = {
  host: "localhost",
  port: 5432,
  user: "postgres",
  password: '6003cem',
  database: "postgres",
  connection_limit: 100
}

// https://www.postgresql.org/download/windows/